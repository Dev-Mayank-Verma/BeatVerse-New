import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/track.dart';

/// BeatVerse music catalog backed by an unofficial JioSaavn-compatible API.
/// This layer keeps the app independent from the old YouTube proxy.
class SaavnService {
  static const _base = 'https://saavnapi-nine.vercel.app';
  final Map<String, _Cache> _cache = {};
  static const _ttl = Duration(minutes: 10);

  Future<List<Track>> search(String q, {int limit = 30}) async {
    if (q.trim().isEmpty) return [];
    return _fetch('/result', {'query': q.trim()}, 'search:$q');
  }

  Future<List<Track>> trending({int limit = 30}) async {
    // The public wrapper does not expose one stable trending contract, so
    // BeatVerse uses curated high-signal discovery queries for a resilient feed.
    final y = DateTime.now().year;
    final queries = <String>[
      'latest hindi songs $y',
      'bollywood hits $y',
      'punjabi hits $y',
    ];
    final all = <Track>[];
    for (final q in queries) {
      all.addAll(await search(q, limit: 12));
    }
    final seen = <String>{};
    return all.where((t) => seen.add(t.id)).take(limit).toList();
  }

  Future<List<Track>> _fetch(
      String path, Map<String, String> params, String key) async {
    final hit = _cache[key];
    if (hit != null && DateTime.now().difference(hit.time) < _ttl) {
      return hit.data;
    }
    final uri = Uri.parse('$_base$path').replace(queryParameters: params);
    final res = await http.get(uri, headers: {'Accept': 'application/json'});
    if (res.statusCode != 200) throw Exception('Saavn API ${res.statusCode}');
    final decoded = jsonDecode(res.body);
    final raw = decoded is Map<String, dynamic>
        ? (decoded['results'] ?? decoded['data'] ?? decoded['songs'] ?? [])
        : decoded;
    final items = raw is List ? raw : <dynamic>[];
    final tracks = items
        .whereType<Map<String, dynamic>>()
        .map(_parse)
        .where((t) => t.title.isNotEmpty)
        .toList();
    _cache[key] = _Cache(tracks, DateTime.now());
    return tracks;
  }

  Track _parse(Map<String, dynamic> item) {
    final id = '${item['id'] ?? item['songid'] ?? item['songId'] ?? ''}';
    final title = '${item['title'] ?? item['song'] ?? ''}'.trim();
    final artist = '${item['singers'] ?? item['subtitle'] ?? item['artist'] ?? ''}'.trim();
    final image = '${item['image_url'] ?? item['image'] ?? item['album_art'] ?? ''}'
        .replaceAll('150x150', '500x500')
        .replaceAll('50x50', '500x500');
    final duration = int.tryParse('${item['duration'] ?? 0}') ?? 0;
    final stream = '${item['url'] ?? item['media_url'] ?? ''}'.trim();
    return Track(
      id: 'saavn-$id',
      title: _clean(title),
      artist: _clean(artist),
      duration: duration,
      thumbnail: image,
      streamOverride: stream.isEmpty ? null : stream,
    );
  }

  String _clean(String s) => s
      .replaceAll('&amp;', '&')
      .replaceAll('&#39;', "'")
      .replaceAll('&quot;', '"')
      .trim();
}

class _Cache {
  final List<Track> data;
  final DateTime time;
  _Cache(this.data, this.time);
}
