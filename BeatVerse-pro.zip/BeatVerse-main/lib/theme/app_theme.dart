import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class AppColors {
  static const background = Color(0xFF07070B); static const surface = Color(0xFF101017); static const card = Color(0xFF15151F); static const cardHover = Color(0xFF20202C);
  static const primary = Color(0xFFB7FF4A); static const primaryGlow = Color(0xFFD4FF86); static const primaryDark = Color(0xFF7FAF28);
  static const foreground = Color(0xFFF7F7FB); static const muted = Color(0xFFA4A4B3); static const mutedForeground = Color(0xFFA4A4B3); static const border = Color(0xFF282833); static const secondary = Color(0xFF1B1B26); static const accent = Color(0xFF9B6CFF); static const destructive = Color(0xFFFF5571); static const error = Color(0xFFFF5571);
  static final vibeGradients = <List<Color>>[[primary, const Color(0xFF15151F)], [accent, const Color(0xFF15151F)], [const Color(0xFFFF4F8B), const Color(0xFF15151F)], [const Color(0xFFFF6B4A), const Color(0xFF15151F)], [const Color(0xFF3EE7FF), const Color(0xFF15151F)], [const Color(0xFFFFD84A), const Color(0xFF15151F)]];
  static final cardGradients = vibeGradients;
}
class AppTheme { static ThemeData get dark { final base=ThemeData.dark(useMaterial3:true); return base.copyWith(scaffoldBackgroundColor:AppColors.background, primaryColor:AppColors.primary, colorScheme:base.colorScheme.copyWith(brightness:Brightness.dark,surface:AppColors.surface,primary:AppColors.primary,onPrimary:Colors.black,secondary:AppColors.accent), cardColor:AppColors.card, dividerColor:AppColors.border, textTheme:GoogleFonts.interTextTheme(base.textTheme).apply(bodyColor:AppColors.foreground,displayColor:AppColors.foreground), appBarTheme:const AppBarTheme(backgroundColor:Colors.transparent,foregroundColor:AppColors.foreground,elevation:0), iconTheme:const IconThemeData(color:AppColors.foreground), splashFactory:InkSparkle.splashFactory); }}
