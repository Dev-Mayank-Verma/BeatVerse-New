import 'package:flutter/material.dart';
import '../models/track.dart';
import '../theme/app_theme.dart';
import 'track_card.dart';

class SectionRow extends StatelessWidget {
  final String       title;
  final List<Track>? tracks;
  final bool         loading;
  const SectionRow({super.key, required this.title,
      required this.tracks, required this.loading});

  @override
  Widget build(BuildContext context) {
    if (!loading && (tracks == null || tracks!.isEmpty)) {
      return const SizedBox.shrink();
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 28),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Text(title, style: const TextStyle(
              fontSize: 20, fontWeight: FontWeight.w800, color: Colors.white)),
        ),
        SizedBox(
          height: 218,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: loading ? 6 : tracks!.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (ctx, i) {
              if (loading) return _skeleton();
              return TrackCard(
                  track: tracks![i], queue: tracks!, index: i);
            },
          ),
        ),
      ]),
    );
  }

  Widget _skeleton() => SizedBox(
    width: 150,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 150, height: 150, decoration: BoxDecoration(
          color: AppColors.card, borderRadius: BorderRadius.circular(8))),
      const SizedBox(height: 8),
      Container(height: 10, width: 100,
          decoration: BoxDecoration(color: AppColors.card,
              borderRadius: BorderRadius.circular(4))),
      const SizedBox(height: 6),
      Container(height: 10, width: 70,
          decoration: BoxDecoration(color: AppColors.cardHover,
              borderRadius: BorderRadius.circular(4))),
    ]),
  );
}
