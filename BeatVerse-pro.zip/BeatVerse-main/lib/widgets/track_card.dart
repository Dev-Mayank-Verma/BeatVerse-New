import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/track.dart';
import '../screens/now_playing_screen.dart';
import '../theme/app_theme.dart';

class TrackCard extends StatelessWidget {
  final Track       track;
  final List<Track> queue;
  final int         index;
  const TrackCard({super.key, required this.track,
      required this.queue, required this.index});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => NowPlayingScreen(
            track: track, queue: queue, initialIndex: index),
      )),
      child: SizedBox(
        width: 150,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Stack(children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: AspectRatio(
                aspectRatio: 1,
                child: CachedNetworkImage(
                  imageUrl: track.thumbnail, fit: BoxFit.cover,
                  placeholder: (_, __) =>
                      Container(color: AppColors.card),
                  errorWidget: (_, __, ___) => Container(
                    color: AppColors.card,
                    child: const Icon(Icons.music_note,
                        color: AppColors.muted, size: 36)),
                ),
              ),
            ),
            Positioned(
              right: 6, bottom: 6,
              child: Container(
                width: 38, height: 38,
                decoration: const BoxDecoration(
                    color: AppColors.primary,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: Colors.black38,
                        blurRadius: 8, offset: Offset(0, 4))]),
                child: const Icon(Icons.play_arrow_rounded,
                    color: Colors.black, size: 20),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          Text(track.title, maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600,
                  fontSize: 13, color: Colors.white)),
          const SizedBox(height: 2),
          Text(track.artist, maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppColors.muted, fontSize: 12)),
        ]),
      ),
    );
  }
}
