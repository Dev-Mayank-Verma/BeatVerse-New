import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/track.dart';
import '../providers/library_provider.dart';
import '../screens/now_playing_screen.dart';
import '../services/tuneproxy_service.dart';
import '../theme/app_theme.dart';
import '../widgets/section_row.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  final _api = SaavnService();
  late final Future<List<Track>> _trending = _api.trending(limit: 24);
  late final Future<List<Track>> _bollywood = _api.search('latest Bollywood Hindi songs ${DateTime.now().year}', limit: 30);
  late final Future<List<Track>> _arijit = _api.search('Arijit Singh', limit: 30);
  late final Future<List<Track>> _punjabi = _api.search('Punjabi hits', limit: 30);
  late final Future<List<Track>> _romantic = _api.search('romantic Hindi songs', limit: 30);
  late final Future<List<Track>> _lofi = _api.search('lofi chill', limit: 30);

  String get _greet { final h = DateTime.now().hour; return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; }
  @override Widget build(BuildContext context) {
    final recent = context.watch<LibraryProvider>().recent;
    return SafeArea(bottom: false, child: CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(18, 18, 18, 8), child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_greet, style: const TextStyle(color: AppColors.muted, fontSize: 13, fontWeight: FontWeight.w600)), const SizedBox(height: 3), const Text('Your sound,\nYour universe.', style: TextStyle(fontSize: 31, height: 1.02, fontWeight: FontWeight.w900))]),
        Container(width: 46, height: 46, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [AppColors.primary, AppColors.accent]), boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(.28), blurRadius: 18)]), child: const Icon(Icons.graphic_eq_rounded, color: Colors.black, size: 25)),
      ]))),
      SliverToBoxAdapter(child: _hero(_trending)),
      if (recent.isNotEmpty) SliverToBoxAdapter(child: _recent(recent)),
      SliverToBoxAdapter(child: _row('🔥 Trending now', _trending)),
      SliverToBoxAdapter(child: _row('🎬 Bollywood — fresh drops', _bollywood)),
      SliverToBoxAdapter(child: _row('🎤 Arijit Singh', _arijit)),
      SliverToBoxAdapter(child: _row('💜 Romantic nights', _romantic)),
      SliverToBoxAdapter(child: _row('⚡ Punjabi energy', _punjabi)),
      SliverToBoxAdapter(child: _row('🌙 Lofi after dark', _lofi)),
      const SliverToBoxAdapter(child: SizedBox(height: 120)),
    ]));
  }
  Widget _hero(Future<List<Track>> f) => FutureBuilder<List<Track>>(future: f, builder: (_, s) {
    final t = s.data?.isNotEmpty == true ? s.data!.first : null;
    return Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 22), child: GestureDetector(onTap: t == null ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => NowPlayingScreen(track: t, queue: s.data!, initialIndex: 0))), child: Container(height: 205, decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF6C2BD9), Color(0xFF1DB954), Color(0xFF0D0D0D)]), boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(.20), blurRadius: 30, offset: const Offset(0, 14))]), child: Stack(children: [
      if (t != null) Positioned(right: -15, top: -20, bottom: -20, width: 220, child: ClipRRect(borderRadius: BorderRadius.circular(28), child: CachedNetworkImage(imageUrl: t.thumbnail, fit: BoxFit.cover, errorWidget: (_, __, ___) => const SizedBox.shrink()))),
      Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: LinearGradient(colors: [Colors.black.withOpacity(.72), Colors.transparent], stops: const [0, .82])))),
      Positioned(left: 22, top: 20, child: Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(99)), child: const Text('BEATVERSE SELECTS', style: TextStyle(fontSize: 10, letterSpacing: 1.6, fontWeight: FontWeight.w900)))),
      Positioned(left: 22, bottom: 22, right: 160, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t?.title ?? 'Loading your vibe…', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(t?.artist ?? 'Fresh music for you', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 12)), const SizedBox(height: 13), Container(width: 42, height: 42, decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white), child: const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 24))])),
    ]))));
  });
  Widget _recent(List<Track> recent) => Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Jump back in', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 10), SizedBox(height: 66, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: recent.take(6).length, separatorBuilder: (_, __) => const SizedBox(width: 10), itemBuilder: (_, i) { final t=recent[i]; return GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NowPlayingScreen(track: t, queue: recent, initialIndex: i))), child: Container(width: 210, padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(14)), child: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(9), child: CachedNetworkImage(imageUrl: t.thumbnail, width: 50, height: 50, fit: BoxFit.cover)), const SizedBox(width: 9), Expanded(child: Text(t.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))), const Icon(Icons.play_circle_fill_rounded, color: AppColors.primary, size: 26)]))); }))]));
  Widget _row(String title, Future<List<Track>> f) => FutureBuilder<List<Track>>(future: f, builder: (_, s) => SectionRow(title: title, tracks: s.data, loading: s.connectionState == ConnectionState.waiting));
}
