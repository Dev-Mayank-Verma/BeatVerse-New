import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../models/track.dart';
import '../providers/library_provider.dart';
import '../theme/app_theme.dart';

class YoutubePlayerScreen extends StatefulWidget {
  final Track       track;
  final List<Track> queue;
  final int         initialIndex;
  const YoutubePlayerScreen({
    super.key,
    required this.track,
    required this.queue,
    required this.initialIndex,
  });
  @override State<YoutubePlayerScreen> createState() => _State();
}

class _State extends State<YoutubePlayerScreen> {
  YoutubePlayerController? _yt;
  late Track _current;
  late int   _idx;
  bool _playerError = false;
  bool _loading     = true;

  @override
  void initState() {
    super.initState();
    _current = widget.track;
    _idx     = widget.initialIndex;
    _initPlayer(_current.videoId);
    context.read<LibraryProvider>().addRecent(_current);
  }

  void _initPlayer(String videoId) {
    _yt?.dispose();
    _playerError = false;
    _loading     = true;
    _yt = YoutubePlayerController(
      initialVideoId: videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        hideControls: false,
        enableCaption: false,
        disableDragSeek: false,
      ),
    )..addListener(() {
        if (!mounted) return;
        if (_yt!.value.hasError) {
          setState(() { _playerError = true; _loading = false; });
          return;
        }
        if (_yt!.value.playerState == PlayerState.ended) _next();
        if (_yt!.value.isReady && _loading) {
          setState(() => _loading = false);
        }
        setState(() {});
      });

    // Timeout — if not ready in 6s, show error
    Future.delayed(const Duration(seconds: 6), () {
      if (mounted && _loading) {
        setState(() { _playerError = true; _loading = false; });
      }
    });
  }

  void _load(Track t, int i) {
    setState(() { _current = t; _idx = i; _loading = true; _playerError = false; });
    _yt?.load(t.videoId);
    context.read<LibraryProvider>().addRecent(t);
  }

  void _next() {
    if (_idx + 1 < widget.queue.length) _load(widget.queue[_idx + 1], _idx + 1);
  }
  void _prev() {
    if (_idx > 0) _load(widget.queue[_idx - 1], _idx - 1);
  }

  Future<void> _openInYoutube() async {
    final uri = Uri.parse('https://www.youtube.com/watch?v=${_current.videoId}');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  void dispose() {
    _yt?.dispose();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_yt == null) return const SizedBox.shrink();
    final liked = context.watch<LibraryProvider>().isLiked(_current.id);

    return YoutubePlayerBuilder(
      onExitFullScreen: () =>
          SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]),
      player: YoutubePlayer(
        controller: _yt!,
        showVideoProgressIndicator: true,
        progressIndicatorColor: AppColors.primary,
        progressColors: ProgressBarColors(
          playedColor:    AppColors.primary,
          handleColor:    AppColors.primaryGlow,
          bufferedColor:  AppColors.primary.withOpacity(0.3),
          backgroundColor: AppColors.border,
        ),
        onReady: () => setState(() => _loading = false),
      ),
      builder: (ctx, ytWidget) => Scaffold(
        backgroundColor: AppColors.background,
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Color(0xFF303030), AppColors.background],
            ),
          ),
          child: SafeArea(
            child: Column(children: [
              // Top bar
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 6, 4, 0),
                child: Row(children: [
                  IconButton(
                    icon: const Icon(Icons.keyboard_arrow_down, size: 30),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                  Expanded(child: Column(children: [
                    const Text('NOW PLAYING', style: TextStyle(
                        fontSize: 10, letterSpacing: 1.5,
                        color: AppColors.muted, fontWeight: FontWeight.w600)),
                    Text(_current.artist, maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  ])),
                  IconButton(
                    icon: const Icon(Icons.more_vert),
                    onPressed: () {},
                  ),
                ]),
              ),

              const SizedBox(height: 8),

              // Player area
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _playerError ? _errorWidget() : Stack(
                    alignment: Alignment.center,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: ytWidget,
                      ),
                      if (_loading) Container(
                        color: Colors.black54,
                        child: const CircularProgressIndicator(
                            color: AppColors.primary),
                      ),
                    ],
                  ),
                ),
              ),

              // Song info
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 4),
                child: Row(children: [
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_current.title, maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(_current.artist, maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: AppColors.muted, fontSize: 14)),
                  ])),
                  IconButton(
                    icon: Icon(
                      liked ? Icons.favorite : Icons.favorite_border,
                      color: liked ? AppColors.primary : AppColors.foreground,
                      size: 26,
                    ),
                    onPressed: () =>
                        context.read<LibraryProvider>().toggleLike(_current),
                  ),
                ]),
              ),

              // Progress
              if (!_playerError) Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(children: [
                  SliderTheme(
                    data: SliderThemeData(
                      trackHeight: 3,
                      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                      overlayShape: SliderComponentShape.noOverlay,
                      activeTrackColor: AppColors.foreground,
                      inactiveTrackColor: AppColors.muted.withOpacity(0.3),
                      thumbColor: AppColors.foreground,
                    ),
                    child: Slider(
                      value: () {
                        final dur = _yt!.value.metaData.duration.inSeconds;
                        if (dur <= 0) return 0.0;
                        return (_yt!.value.position.inSeconds / dur).clamp(0.0, 1.0);
                      }(),
                      onChanged: (v) {
                        final sec = (_yt!.value.metaData.duration.inSeconds * v).round();
                        _yt!.seekTo(Duration(seconds: sec));
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(_fmt(_yt!.value.position),
                            style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                        Text(_fmt(_yt!.value.metaData.duration),
                            style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                      ],
                    ),
                  ),
                ]),
              ),

              // Controls
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.shuffle_rounded, size: 22),
                      color: AppColors.muted, onPressed: () {},
                    ),
                    IconButton(
                      iconSize: 36,
                      icon: const Icon(Icons.skip_previous_rounded),
                      color: _idx > 0 ? AppColors.foreground : AppColors.muted,
                      onPressed: _idx > 0 ? _prev : null,
                    ),
                    GestureDetector(
                      onTap: () {
                        _yt!.value.isPlaying ? _yt!.pause() : _yt!.play();
                        setState(() {});
                      },
                      child: Container(
                        width: 64, height: 64,
                        decoration: const BoxDecoration(
                          color: AppColors.foreground, shape: BoxShape.circle),
                        child: Icon(
                          _yt!.value.isPlaying
                              ? Icons.pause_rounded : Icons.play_arrow_rounded,
                          color: AppColors.background, size: 36,
                        ),
                      ),
                    ),
                    IconButton(
                      iconSize: 36,
                      icon: const Icon(Icons.skip_next_rounded),
                      color: _idx < widget.queue.length - 1
                          ? AppColors.foreground : AppColors.muted,
                      onPressed: _idx < widget.queue.length - 1 ? _next : null,
                    ),
                    IconButton(
                      icon: const Icon(Icons.repeat_rounded, size: 22),
                      color: AppColors.muted, onPressed: () {},
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _errorWidget() => Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      CachedNetworkImage(
        imageUrl: _current.thumbnail,
        width: double.infinity,
        fit: BoxFit.cover,
        errorWidget: (_, __, ___) => Container(
          height: 200, color: AppColors.card,
          child: const Icon(Icons.music_note, size: 64, color: AppColors.muted)),
      ),
      const SizedBox(height: 20),
      const Text('Tap below to play on YouTube',
          style: TextStyle(color: AppColors.muted, fontSize: 13)),
      const SizedBox(height: 12),
      ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: const StadiumBorder(),
        ),
        icon: const Icon(Icons.play_arrow_rounded),
        label: const Text('Open in YouTube', style: TextStyle(fontWeight: FontWeight.bold)),
        onPressed: _openInYoutube,
      ),
    ],
  );

  String _fmt(Duration d) {
    final m = d.inMinutes; final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}
