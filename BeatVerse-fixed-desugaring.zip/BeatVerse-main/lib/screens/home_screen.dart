import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/track.dart';
import '../providers/library_provider.dart';
import '../screens/youtube_player_screen.dart';
import '../services/tuneproxy_service.dart';
import '../theme/app_theme.dart';
import '../widgets/section_row.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _api = TuneProxyService();
  final int  _yr = DateTime.now().year;

  late Future<List<Track>> _trending;
  late Future<List<Track>> _arijit;
  late Future<List<Track>> _bollywood;
  late Future<List<Track>> _punjabi;
  late Future<List<Track>> _english;
  late Future<List<Track>> _romantic;

  @override
  void initState() {
    super.initState();
    _trending  = _api.trending();
    _arijit    = _api.search('Arijit Singh songs $_yr');
    _bollywood = _api.search('New Bollywood songs $_yr Hindi');
    _punjabi   = _api.search('Top Punjabi songs $_yr');
    _english   = _api.search('Top English hits $_yr');
    _romantic  = _api.search('Romantic Hindi songs $_yr');
  }

  String get _greet {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context) {
    final recent = context.watch<LibraryProvider>().recent;

    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        slivers: [
          // Greeting
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Text(_greet, style: const TextStyle(
                  fontSize: 26, fontWeight: FontWeight.w800,
                  color: Colors.white)),
            ),
          ),

          // Recently played — Spotify 2-col grid
          if (recent.isNotEmpty) ...[
            const SliverToBoxAdapter(child: SizedBox(height: 16)),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, childAspectRatio: 3.8,
                  mainAxisSpacing: 8, crossAxisSpacing: 8),
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) {
                    if (i >= recent.take(6).length) return null;
                    final t = recent[i];
                    return GestureDetector(
                      onTap: () => Navigator.of(ctx).push(MaterialPageRoute(
                        builder: (_) => YoutubePlayerScreen(
                            track: t, queue: recent, initialIndex: i))),
                      child: Container(
                        decoration: BoxDecoration(
                            color: AppColors.card,
                            borderRadius: BorderRadius.circular(6)),
                        child: Row(children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(6),
                                bottomLeft: Radius.circular(6)),
                            child: CachedNetworkImage(
                                imageUrl: t.thumbnail, width: 48,
                                height: 48, fit: BoxFit.cover,
                                errorWidget: (_, __, ___) => Container(
                                    width: 48, height: 48,
                                    color: AppColors.cardHover)),
                          ),
                          const SizedBox(width: 8),
                          Expanded(child: Text(t.title, maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white))),
                          const SizedBox(width: 4),
                        ]),
                      ),
                    );
                  },
                  childCount: recent.take(6).length,
                ),
              ),
            ),
          ],

          const SliverToBoxAdapter(child: SizedBox(height: 24)),

          // Sections
          SliverToBoxAdapter(child: _row('🔥 Trending in India', _trending)),
          SliverToBoxAdapter(child: _row('🎤 Arijit Singh', _arijit)),
          SliverToBoxAdapter(child: _row('🎬 New Bollywood $_yr', _bollywood)),
          SliverToBoxAdapter(child: _row('🎵 Punjabi Vibes', _punjabi)),
          SliverToBoxAdapter(child: _row('💕 Romantic Hits', _romantic)),
          SliverToBoxAdapter(child: _row('🌍 English Charts', _english)),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
    );
  }

  Widget _row(String title, Future<List<Track>> f) =>
      FutureBuilder<List<Track>>(
        future: f,
        builder: (ctx, s) => SectionRow(
          title: title, tracks: s.data,
          loading: s.connectionState == ConnectionState.waiting),
      );
}
