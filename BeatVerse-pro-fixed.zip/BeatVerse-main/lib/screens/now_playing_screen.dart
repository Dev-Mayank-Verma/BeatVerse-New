import 'dart:ui';
import 'package:audio_session/audio_session.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../models/track.dart';
import '../providers/library_provider.dart';
import '../theme/app_theme.dart';

class NowPlayingScreen extends StatefulWidget {
  final Track track;
  final List<Track> queue;
  final int initialIndex;

  const NowPlayingScreen({
    super.key,
    required this.track,
    required this.queue,
    required this.initialIndex,
  });

  @override
  State<NowPlayingScreen> createState() => _NowPlayingScreenState();
}

class _NowPlayingScreenState extends State<NowPlayingScreen>
    with SingleTickerProviderStateMixin {
  late final AudioPlayer _player;
  late int _index;
  late Track _current;
  late AnimationController _spin;

  bool _loading = true;
  bool _shuffle = false;
  LoopMode _loop = LoopMode.off;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _index = widget.initialIndex.clamp(0, widget.queue.length - 1);
    _current = widget.queue[_index];
    _spin = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
    _configure();

    _player.playerStateStream.listen((state) {
      if (!mounted) return;
      if (state.processingState == ProcessingState.completed) {
        _next();
      }
      setState(() {});
    });
  }

  Future<void> _configure() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
    await _loadCurrent();
  }

  Future<void> _loadCurrent() async {
    if (!mounted) return;
    setState(() => _loading = true);

    final url = _current.streamOverride;
    if (url == null || url.isEmpty) {
      if (mounted) setState(() => _loading = false);
      return;
    }

    try {
      await _player.setUrl(url);
      if (mounted) {
        context.read<LibraryProvider>().addRecent(_current);
      }
      await _player.play();
    } catch (_) {
      // Keep the player UI usable if a remote stream is unavailable.
    }

    if (mounted) setState(() => _loading = false);
  }

  Future<void> _next() async {
    if (widget.queue.isEmpty) return;

    if (_shuffle && widget.queue.length > 1) {
      _index = (_index + 1 + DateTime.now().millisecond) % widget.queue.length;
    } else if (_index + 1 < widget.queue.length) {
      _index++;
    } else if (_loop == LoopMode.all) {
      _index = 0;
    } else {
      return;
    }

    _current = widget.queue[_index];
    await _loadCurrent();
  }

  Future<void> _previous() async {
    if (_player.position > const Duration(seconds: 4)) {
      await _player.seek(Duration.zero);
      return;
    }

    if (_index == 0) return;
    _index--;
    _current = widget.queue[_index];
    await _loadCurrent();
  }

  @override
  void dispose() {
    _player.dispose();
    _spin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final liked = context.watch<LibraryProvider>().isLiked(_current.id);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          Positioned.fill(
            child: CachedNetworkImage(
              imageUrl: _current.thumbnail,
              fit: BoxFit.cover,
              color: Colors.black.withOpacity(.52),
              colorBlendMode: BlendMode.darken,
              errorWidget: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 26, sigmaY: 26),
              child: Container(
                color: AppColors.background.withOpacity(.72),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
                      ),
                      const Expanded(
                        child: Center(
                          child: Text(
                            'NOW PLAYING',
                            style: TextStyle(
                              fontSize: 11,
                              letterSpacing: 2,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () {},
                        icon: const Icon(Icons.more_horiz_rounded),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                RotationTransition(
                  turns: _spin,
                  child: Container(
                    width: 285,
                    height: 285,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(.22),
                          blurRadius: 50,
                          spreadRadius: 10,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: CachedNetworkImage(
                        imageUrl: _current.thumbnail,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => Container(
                          color: AppColors.card,
                          child: const Icon(Icons.music_note_rounded, size: 90),
                        ),
                      ),
                    ),
                  ),
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 0, 24, 0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _current.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              _current.artist,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppColors.muted,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () => context.read<LibraryProvider>().toggleLike(_current),
                        icon: Icon(
                          liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                          color: liked ? AppColors.primary : Colors.white,
                          size: 28,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                StreamBuilder<Duration>(
                  stream: _player.positionStream,
                  builder: (_, snapshot) {
                    final position = snapshot.data ?? Duration.zero;
                    final duration = _player.duration ?? Duration.zero;
                    final max = duration.inMilliseconds <= 0
                        ? 1.0
                        : duration.inMilliseconds.toDouble();
                    final value = position.inMilliseconds
                        .clamp(0, duration.inMilliseconds)
                        .toDouble();

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Column(
                        children: [
                          SliderTheme(
                            data: SliderTheme.of(context).copyWith(
                              trackHeight: 3,
                              thumbShape: const RoundSliderThumbShape(
                                enabledThumbRadius: 6,
                              ),
                              overlayShape: SliderComponentShape.noOverlay,
                            ),
                            child: Slider(
                              value: value,
                              min: 0,
                              max: max,
                              onChanged: duration.inMilliseconds <= 0
                                  ? null
                                  : (v) => _player.seek(
                                        Duration(milliseconds: v.round()),
                                      ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _fmt(position),
                                  style: const TextStyle(
                                    color: AppColors.muted,
                                    fontSize: 11,
                                  ),
                                ),
                                Text(
                                  _fmt(duration),
                                  style: const TextStyle(
                                    color: AppColors.muted,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      onPressed: () => setState(() => _shuffle = !_shuffle),
                      icon: Icon(
                        Icons.shuffle_rounded,
                        color: _shuffle ? AppColors.primary : AppColors.muted,
                      ),
                    ),
                    IconButton(
                      onPressed: _previous,
                      icon: const Icon(Icons.skip_previous_rounded, size: 38),
                    ),
                    StreamBuilder<PlayerState>(
                      stream: _player.playerStateStream,
                      builder: (_, snapshot) {
                        final playing = snapshot.data?.playing ?? false;
                        return Container(
                          width: 68,
                          height: 68,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.foreground,
                          ),
                          child: IconButton(
                            icon: Icon(
                              playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                              color: Colors.black,
                              size: 34,
                            ),
                            onPressed: _loading
                                ? null
                                : () => playing ? _player.pause() : _player.play(),
                          ),
                        );
                      },
                    ),
                    IconButton(
                      onPressed: _next,
                      icon: const Icon(Icons.skip_next_rounded, size: 38),
                    ),
                    IconButton(
                      onPressed: () => setState(
                        () => _loop = _loop == LoopMode.off ? LoopMode.all : LoopMode.off,
                      ),
                      icon: Icon(
                        _loop == LoopMode.all
                            ? Icons.repeat_on_rounded
                            : Icons.repeat_rounded,
                        color: _loop == LoopMode.all
                            ? AppColors.primary
                            : AppColors.muted,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _fmt(Duration duration) =>
      '${duration.inMinutes}:${(duration.inSeconds % 60).toString().padLeft(2, '0')}';
}
